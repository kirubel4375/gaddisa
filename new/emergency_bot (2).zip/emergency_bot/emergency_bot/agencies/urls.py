"""URL configuration for the agencies app."""

from django.urls import path
from . import views

urlpatterns = [
    # API endpoints for agencies
    path('api/agencies/nearby/', views.nearby_agencies, name='api_nearby_agencies'),
    path('api/agencies/search/', views.search_agencies, name='api_search_agencies'),
    path('api/locations/zones/', views.get_zones, name='api_get_zones'),
    path('api/locations/woredas/', views.get_woredas, name='api_get_woredas'),
    path('api/locations/kebeles/', views.get_kebeles, name='api_get_kebeles'),
] 