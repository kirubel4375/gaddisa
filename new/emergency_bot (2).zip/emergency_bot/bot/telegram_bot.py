import os
import sys
import django

# Setup Django
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'emergency_bot.settings')
django.setup()

# Import Django settings and models
from django.conf import settings
from bot.models import Location, Service, UserRequestLog

# Import Telegram libraries
from asgiref.sync import sync_to_async

from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ConversationHandler, filters, ContextTypes, CallbackContext
import logging



# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)
logger = logging.getLogger(__name__)

# States
CHOOSING_SERVICE = 1

# Service Type to Human-friendly name
service_type_display = {
    'hospital': 'Hospital',
    'police': 'Police',
    'ambulance': 'Ambulance',
    'women_child_affair': 'Women and Child Affair'
}

# Start Command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    reply_keyboard = [['Hospital', 'Police'], ['Ambulance', 'Women and Child Affair']]
    await update.message.reply_text(
        "Hi! I can help you find emergency services.\n\n"
        "Please choose one of the following:",
        reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True, resize_keyboard=True)
    )
    return CHOOSING_SERVICE

# Handle Service Choice
async def choose_service(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_choice = update.message.text.lower().replace(' ', '_')

    if user_choice not in service_type_display:
        await update.message.reply_text('Invalid choice. Please select again.')
        return CHOOSING_SERVICE

    # Skip logging for now
    logger.info(f"User chose: {user_choice}, skipping UserRequestLog")

    # Find service
    service = await sync_to_async(Service.objects.filter(service_type=user_choice).first)()

    if service:
        location_link = f"https://maps.google.com/?q={service.location.latitude},{service.location.longitude}"
        response = (
            f"Here is a nearby {service_type_display[user_choice]}:\n\n"
            f"*Name:* {service.name}\n"
            f"*Phone:* {service.phone_number}\n"
            f"*Description:* {service.description}\n"
            f"*Location:* [Google Maps]({location_link})"
        )
        await update.message.reply_text(response, parse_mode="Markdown")
    else:
        await update.message.reply_text(f"Sorry, no {service_type_display[user_choice]} found.")

    return ConversationHandler.END
# Cancel command
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text('Operation cancelled. Type /start to begin again.')
    return ConversationHandler.END

def main() -> None:
    app = ApplicationBuilder().token(settings.TELEGRAM_BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            CHOOSING_SERVICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, choose_service)],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
    )

    app.add_handler(conv_handler)

    print("Bot is running...")
    app.run_polling()

if __name__ == '__main__':
    main()
