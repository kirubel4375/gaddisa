from django.db import models
from django.utils import timezone
from django.conf import settings
import uuid
from cryptography.fernet import Fernet
import base64

# For encryption of sensitive data
def get_encryption_key():
    from django.conf import settings
    key = getattr(settings, 'ENCRYPTION_KEY', None)
    if key:
        return base64.urlsafe_b64decode(key)
    return None

def encrypt_text(text):
    key = get_encryption_key()
    if key and text:
        f = Fernet(key)
        return f.encrypt(text.encode()).decode()
    return text

def decrypt_text(encrypted_text):
    key = get_encryption_key()
    if key and encrypted_text:
        f = Fernet(key)
        return f.decrypt(encrypted_text.encode()).decode()
    return encrypted_text


class IncidentReport(models.Model):
    INCIDENT_TYPES = (
        ('rape', 'Rape'),
        ('assault', 'Assault'),
        ('domestic_violence', 'Domestic Violence'),
        ('harassment', 'Harassment'),
        ('other', 'Other'),
    )
    
    STATUS_CHOICES = (
        ('submitted', 'Submitted'),
        ('processing', 'Processing'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed'),
    )
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey('accounts.UserProfile', on_delete=models.CASCADE, related_name='reports')
    type = models.CharField(max_length=50, choices=INCIDENT_TYPES)
    description = models.TextField(null=True, blank=True)
    description_encrypted = models.TextField(null=True, blank=True)
    voice_note_url = models.URLField(max_length=255, null=True, blank=True)
    location = models.CharField(max_length=255)
    latitude = models.FloatField()
    longitude = models.FloatField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='submitted')
    submitted_at = models.DateTimeField(default=timezone.now)
    last_updated = models.DateTimeField(auto_now=True)
    
    # Audit fields
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    device_info = models.CharField(max_length=255, null=True, blank=True)
    
    class Meta:
        verbose_name = "Incident Report"
        verbose_name_plural = "Incident Reports"
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['type']),
            models.Index(fields=['status']),
            models.Index(fields=['submitted_at']),
        ]
        ordering = ['-submitted_at']
    
    def __str__(self):
        return f"{self.get_type_display()} - {self.submitted_at}"
    
    def save(self, *args, **kwargs):
        # Encrypt description if provided
        if self.description and not self.description_encrypted:
            self.description_encrypted = encrypt_text(self.description)
            # For GDPR compliance, we can optionally clear the plaintext
            # self.description = None
        
        super().save(*args, **kwargs)
    
    def get_decrypted_description(self):
        if self.description_encrypted:
            return decrypt_text(self.description_encrypted)
        return self.description
        
    @property
    def time_since_submission(self):
        return timezone.now() - self.submitted_at 