"""
URL configuration for the emergency_bot project.
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Include frontend URLs
    path('', include('emergency_bot.frontend.urls')),
    
    # Include agencies URLs
    path('', include('emergency_bot.agencies.urls')),
    
    # Include accounts URLs
    path('', include('emergency_bot.accounts.urls')),
    
    # Include reports URLs
    path('', include('emergency_bot.reports.urls')),
    
    # Include telegram bot URLs
    path('telegram/', include('emergency_bot.telegram_bot.urls')),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
