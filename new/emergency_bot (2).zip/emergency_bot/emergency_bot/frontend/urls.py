"""
URL configuration for the frontend app.
"""

from django.urls import path
from . import views

urlpatterns = [
    # Main WebApp entry point
    path('', views.index, name='index'),
    
    # Welcome/onboarding page for first-time users
    path('welcome/', views.welcome, name='welcome'),
    
    # User preferences update endpoints
    path('update-language/', views.update_language, name='update_language'),
    path('update-consent/', views.update_consent, name='update_consent'),
    
    # Report incident page
    path('report/', views.report_incident, name='report_incident'),
    
    # Submit report endpoint
    path('report/submit/', views.submit_report, name='submit_report'),
    
    # Find agencies page
    path('agencies/', views.find_agencies, name='find_agencies'),
    
    # User profile page
    path('profile/', views.user_profile, name='user_profile'),
    
    # Report history
    path('reports/', views.report_history, name='report_history'),
] 