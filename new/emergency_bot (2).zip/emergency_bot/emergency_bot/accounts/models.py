from django.db import models
from django.utils import timezone


class UserProfile(models.Model):
    telegram_id = models.CharField(max_length=50, unique=True)
    language = models.CharField(
        max_length=10, 
        default="en",
        choices=(
            ("en", "English"),
            ("am", "Amharic"),
            ("om", "Afaan Oromo"),
        )
    )
    last_active = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Additional fields for GDPR compliance
    data_consent = models.BooleanField(default=False)
    consent_date = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = "User Profile"
        verbose_name_plural = "User Profiles"
        indexes = [
            models.Index(fields=["telegram_id"]),
        ]
    
    def __str__(self):
        return f"User {self.telegram_id}"
    
    def update_last_active(self):
        self.last_active = timezone.now()
        self.save(update_fields=["last_active"])
    
    def grant_consent(self):
        self.data_consent = True
        self.consent_date = timezone.now()
        self.save(update_fields=["data_consent", "consent_date"])
    
    def revoke_consent(self):
        self.data_consent = False
        self.save(update_fields=["data_consent"]) 