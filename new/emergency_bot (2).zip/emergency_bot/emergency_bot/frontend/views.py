"""
Views for the frontend app.
"""

import json
import logging
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.conf import settings
from emergency_bot.accounts.models import UserProfile
from emergency_bot.reports.models import IncidentReport
from emergency_bot.agencies.models import Agency

from emergency_bot.accounts.middleware import telegram_auth_required

logger = logging.getLogger(__name__)


def get_user_profile(request):
    """Get or create UserProfile from Telegram user ID in query params"""
    telegram_id = request.GET.get('user_id')
    
    if not telegram_id:
        logger.warning("No user_id provided in request")
        return None
    
    try:
        user_profile, created = UserProfile.objects.get_or_create(
            telegram_id=telegram_id
        )
        
        # Update last active time
        user_profile.update_last_active()
        
        # For debugging
        if created:
            logger.info(f"Created new user profile for Telegram ID: {telegram_id}")
        
        # Add user_profile to request for use in other views
        request.user_profile = user_profile
        return user_profile
    
    except Exception as e:
        logger.error(f"Error getting user profile: {e}")
        return None


@telegram_auth_required
def index(request):
    """
    Main entry point for the Telegram Mini App.
    Check if this is a first-time user and redirect to onboarding if needed.
    """
    # Check if user has seen onboarding
    user_profile = request.user_profile
    onboarded = request.GET.get('onboarded', 'false')
    
    # If user hasn't given consent and hasn't just completed onboarding,
    # redirect to welcome/onboarding page
    if not user_profile.data_consent and onboarded != 'true':
        return redirect('welcome')
    
    return render(request, 'index.html')


@telegram_auth_required
def welcome(request):
    """
    Welcome screen for first-time users with onboarding steps.
    """
    return render(request, 'welcome.html')


@telegram_auth_required
@require_POST
@csrf_exempt
def update_language(request):
    """
    Update user's language preference.
    """
    try:
        data = json.loads(request.body)
        language = data.get('language')
        
        if language not in ['en', 'am', 'om']:
            return JsonResponse({'success': False, 'error': 'Invalid language'})
        
        # Update user profile
        user_profile = request.user_profile
        user_profile.language = language
        user_profile.save(update_fields=['language'])
        
        return JsonResponse({'success': True})
    except Exception as e:
        logger.error(f"Error updating language: {e}")
        return JsonResponse({'success': False, 'error': str(e)})


@telegram_auth_required
@require_POST
@csrf_exempt
def update_consent(request):
    """
    Update user's data consent preference.
    """
    try:
        data = json.loads(request.body)
        consent = data.get('consent', False)
        
        # Update user profile
        user_profile = request.user_profile
        
        if consent:
            user_profile.grant_consent()
        else:
            user_profile.revoke_consent()
        
        return JsonResponse({'success': True})
    except Exception as e:
        logger.error(f"Error updating consent: {e}")
        return JsonResponse({'success': False, 'error': str(e)})


@telegram_auth_required
def report_incident(request):
    """
    Display the incident reporting form.
    """
    return render(request, 'report.html')


@telegram_auth_required
@require_POST
def submit_report(request):
    """
    Handle incident report submission.
    """
    try:
        # Extract data from request
        incident_type = request.POST.get('type')
        description = request.POST.get('description', '')
        latitude = request.POST.get('latitude')
        longitude = request.POST.get('longitude')
        location = request.POST.get('location', '')
        voice_note_url = request.POST.get('voice_note_url', '')
        
        # Validate required fields
        if not incident_type or not latitude or not longitude:
            return HttpResponseBadRequest("Missing required fields")
        
        # Create the incident report
        report = IncidentReport.objects.create(
            user=request.user.userprofile,
            type=incident_type,
            description=description,
            location=location,
            latitude=float(latitude),
            longitude=float(longitude),
            voice_note_url=voice_note_url
        )
        
        # Return success response
        return JsonResponse({
            'success': True,
            'report_id': str(report.id)
        })
    
    except Exception as e:
        logger.error(f"Error submitting report: {e}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@telegram_auth_required
def find_agencies(request):
    """
    Display the page for finding nearby support agencies.
    """
    # Get unique regions for the filter dropdown
    regions = Agency.objects.values_list('region', flat=True).distinct()
    
    return render(request, 'agencies.html', {
        'regions': regions
    })


@telegram_auth_required
def user_profile(request):
    """
    Display and manage user profile.
    """
    return render(request, 'profile.html', {
        'user': request.user.userprofile
    })


@telegram_auth_required
def report_history(request):
    """
    Display the user's report history.
    """
    reports = IncidentReport.objects.filter(user=request.user.userprofile).order_by('-submitted_at')
    
    return render(request, 'reports.html', {
        'reports': reports
    })


def agency_detail(request, slug):
    """View details of a specific agency"""
    # Get user profile
    user_profile = get_user_profile(request)
    if not user_profile:
        return HttpResponseBadRequest("Invalid user ID")
    
    # Get agency
    agency = get_object_or_404(Agency, slug=slug, active=True)
    
    return render(request, 'agency_detail.html', {
        'user_profile': user_profile,
        'agency': agency,
    })


def my_reports(request):
    """View user's reports"""
    # Get user profile
    user_profile = get_user_profile(request)
    if not user_profile:
        return HttpResponseBadRequest("Invalid user ID")
    
    # Get user's reports
    reports = IncidentReport.objects.filter(user=user_profile).order_by('-submitted_at')
    
    return render(request, 'my_reports.html', {
        'user_profile': user_profile,
        'reports': reports,
    })


def report_detail(request, report_id):
    """View details of a specific report"""
    # Get user profile
    user_profile = get_user_profile(request)
    if not user_profile:
        return HttpResponseBadRequest("Invalid user ID")
    
    # Get report (ensure it belongs to the user)
    report = get_object_or_404(IncidentReport, id=report_id, user=user_profile)
    
    return render(request, 'report_detail.html', {
        'user_profile': user_profile,
        'report': report,
    }) 