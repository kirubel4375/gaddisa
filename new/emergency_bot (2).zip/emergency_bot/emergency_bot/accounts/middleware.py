"""
Middleware for handling Telegram user authentication.
"""

import logging
import json
import hashlib
import hmac
import time
from urllib.parse import parse_qsl
from functools import wraps

from django.conf import settings
from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponseForbidden

from .models import UserProfile

logger = logging.getLogger(__name__)


class TelegramAuthMiddleware(MiddlewareMixin):
    """
    Middleware to authenticate Telegram users via Telegram WebApp init data.
    
    The middleware looks for 'X-User-ID' header or 'user_id' query parameter
    to identify the Telegram user accessing the API endpoints.
    
    For WebApp API requests, it also validates the Telegram Web App init_data
    when available in the 'X-Telegram-Init-Data' header.
    """
    
    def process_request(self, request):
        """Process each request and authenticate Telegram user."""
        # DEVELOPMENT BYPASS - Simply return None to skip authentication
        # Set to True during development for browser testing
        bypass_auth = False  # Changed from True to False for proper user registration
        if bypass_auth:
            # Create a fake user profile for development
            request.user_profile = UserProfile.objects.get_or_create(
                telegram_id='12345'
            )[0]
            return None
            
        # Skip authentication for admin, static, or non-API paths
        if request.path.startswith('/admin/') or \
           request.path.startswith(settings.STATIC_URL) or \
           request.path.startswith(settings.MEDIA_URL) or \
           not (request.path.startswith('/api/') or request.path.startswith('/webapp/')):
            return None
        
        # Get user ID from header or query parameter
        telegram_id = None
        
        # First try header (useful for API requests)
        if 'HTTP_X_USER_ID' in request.META:
            telegram_id = request.META.get('HTTP_X_USER_ID')
        
        # Then try query parameter (used in WebApp URLs)
        if not telegram_id and 'user_id' in request.GET:
            telegram_id = request.GET.get('user_id')
        
        if not telegram_id:
            # Skip authentication if no user ID found
            # This allows public API endpoints
            return None
        
        # Check if we have Telegram init_data for stronger authentication
        init_data = request.META.get('HTTP_X_TELEGRAM_INIT_DATA')
        
        if init_data and settings.TELEGRAM_BOT_TOKEN:
            # Validate Telegram Web App init_data
            is_valid = self._validate_init_data(init_data)
            if not is_valid:
                logger.warning(f"Invalid Telegram init_data for user: {telegram_id}")
                return HttpResponseForbidden("Invalid authentication data")
                
            # Extract user_id from init_data to verify it matches
            try:
                # Parse query string format
                data_dict = dict(parse_qsl(init_data))
                
                if 'user' in data_dict:
                    user_data = json.loads(data_dict['user'])
                    init_user_id = str(user_data.get('id'))
                    
                    if telegram_id != init_user_id:
                        logger.warning(f"User ID mismatch: {telegram_id} vs {init_user_id}")
                        return HttpResponseForbidden("User ID mismatch")
            except:
                # If we can't parse, we already validated the hash anyway
                pass
        
        # Get or create user profile
        try:
            user_profile, created = UserProfile.objects.get_or_create(
                telegram_id=telegram_id
            )
            
            # Update last active timestamp
            user_profile.update_last_active()
            
            # Attach to request
            request.user_profile = user_profile
            
        except Exception as e:
            logger.error(f"Error authenticating Telegram user: {e}")
            return HttpResponseForbidden("Authentication error")
        
        return None
    
    def _validate_init_data(self, init_data):
        """
        Validate Telegram WebApp init_data.
        
        This verifies the hash in the init_data matches an HMAC-SHA256
        of the data using the bot token as the key.
        
        Args:
            init_data (str): Telegram WebApp init_data string
            
        Returns:
            bool: True if valid, False otherwise
        """
        try:
            # Parse init_data query string
            data_dict = dict(parse_qsl(init_data))
            
            # Extract hash and remove from data
            received_hash = data_dict.pop('hash', '')
            
            # Sort alphabetically by key
            sorted_data = sorted(data_dict.items())
            
            # Join data as key=value pairs
            data_string = '\n'.join([f"{k}={v}" for k, v in sorted_data])
            
            # Create secret key from bot token
            secret_key = hmac.new(
                b"WebAppData",
                settings.TELEGRAM_BOT_TOKEN.encode(),
                hashlib.sha256
            ).digest()
            
            # Calculate HMAC-SHA256
            calculated_hash = hmac.new(
                secret_key,
                data_string.encode(),
                hashlib.sha256
            ).hexdigest()
            
            # Check if hashes match
            return hmac.compare_digest(received_hash, calculated_hash)
        except Exception as e:
            logger.error(f"Error validating init_data: {e}")
            return False 

def telegram_auth_required(view_func):
    """
    Decorator to ensure a view is only accessible to authenticated Telegram users.
    
    This decorator checks if request.user_profile exists, which should be set by
    the TelegramAuthMiddleware if authentication was successful.
    """
    @wraps(view_func)
    def wrapped_view(request, *args, **kwargs):
        # DEVELOPMENT BYPASS - Skip authentication check for browser testing
        bypass_auth = False  # Changed from True to False for proper user registration
        if bypass_auth:
            if not hasattr(request, 'user_profile') or not request.user_profile:
                # Create a fake user profile
                request.user_profile = UserProfile.objects.get_or_create(
                    telegram_id='12345'
                )[0]
            return view_func(request, *args, **kwargs)
            
        # Check if user is authenticated via Telegram
        if not hasattr(request, 'user_profile') or not request.user_profile:
            # If not authenticated, try to get user_id from query params
            telegram_id = request.GET.get('user_id')
            if telegram_id:
                try:
                    user_profile, created = UserProfile.objects.get_or_create(
                        telegram_id=telegram_id
                    )
                    user_profile.update_last_active()
                    request.user_profile = user_profile
                except Exception as e:
                    logger.error(f"Error in telegram_auth_required: {e}")
                    return HttpResponseForbidden("Authentication required")
            else:
                return HttpResponseForbidden("Authentication required")
        
        # Call the view function
        return view_func(request, *args, **kwargs)
    
    return wrapped_view 