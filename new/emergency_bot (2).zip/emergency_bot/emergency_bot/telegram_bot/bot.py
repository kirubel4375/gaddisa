import logging
import os
import sys
import requests
import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)
from django.conf import settings
from emergency_bot.accounts.models import UserProfile

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Get the bot token from settings
BOT_TOKEN = settings.TELEGRAM_BOT_TOKEN

# Check multiple sources for the URL in order of reliability
def get_webapp_url():
    """Get the WebApp URL from multiple possible sources, in order of reliability"""
    
    # Check ngrok_url.txt first (most reliable as it's managed by update_ngrok_url.py)
    ngrok_url_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "ngrok_url.txt")
    if os.path.exists(ngrok_url_path):
        try:
            modified_time = os.path.getmtime(ngrok_url_path)
            # Check if file was modified in the last 30 minutes
            if time.time() - modified_time < 1800:  # 30 minutes in seconds
                with open(ngrok_url_path, 'r') as f:
                    url = f.read().strip()
                    if url and (url.startswith("http://") or url.startswith("https://")):
                        logger.info(f"Using URL from ngrok_url.txt: {url}")
                        # Test the URL to make sure it's reachable
                        try:
                            response = requests.head(url, timeout=5)
                            if response.status_code < 500:  # Accept any non-server error response
                                return url
                            else:
                                logger.warning(f"URL from ngrok_url.txt returned status {response.status_code}")
                        except Exception as e:
                            logger.warning(f"Error testing URL from ngrok_url.txt: {e}")
        except Exception as e:
            logger.warning(f"Error reading ngrok_url.txt: {e}")
    
    # Check environment variable
    env_url = os.environ.get('WEBAPP_URL')
    if env_url and (env_url.startswith("http://") or env_url.startswith("https://")):
        logger.info(f"Using URL from environment: {env_url}")
        return env_url
    
    # Check command line arguments
    if len(sys.argv) > 2:
        for arg in sys.argv:
            if arg.startswith('--webapp_url='):
                cmd_url = arg.split('=')[1]
                if cmd_url and (cmd_url.startswith("http://") or cmd_url.startswith("https://")):
                    logger.info(f"Using URL from command line: {cmd_url}")
                    return cmd_url
    
    # Try to get from ngrok API as last resort
    try:
        response = requests.get("http://localhost:4040/api/tunnels", timeout=3)
        if response.status_code == 200:
            data = response.json()
            tunnels = data.get("tunnels", [])
            if tunnels:
                for tunnel in tunnels:
                    public_url = tunnel.get("public_url")
                    if public_url and public_url.startswith("https"):
                        logger.info(f"Using URL from ngrok API: {public_url}")
                        return public_url
    except Exception as e:
        logger.warning(f"Could not get URL from ngrok API: {e}")
    
    # Fallback to a default URL
    logger.warning("Using fallback URL - this may not work!")
    return "https://emergency-bot.loca.lt"  # Change this to a more reliable default if available

# Get the WebApp URL
WEBAPP_URL = get_webapp_url()
logger.info(f"Using WebApp URL: {WEBAPP_URL}")

# Function to create a WebAppInfo button with retry logic
def create_webapp_button(user_id):
    """Create a WebApp button with error checking"""
    url = f"{WEBAPP_URL}?user_id={user_id}"
    
    # Verify the URL is accessible
    try:
        response = requests.head(url, timeout=5)
        if response.status_code >= 500:
            logger.warning(f"Warning: WebApp URL returned status {response.status_code}")
    except Exception as e:
        logger.warning(f"Warning: Could not verify WebApp URL: {e}")
    
    return WebAppInfo(url=url)

async def get_or_create_user(telegram_id, first_name=None):
    """Get or create a user profile, returns (user_profile, is_new_user)"""
    try:
        user_profile, created = UserProfile.objects.get_or_create(
            telegram_id=telegram_id
        )
        
        # Update last active time
        user_profile.update_last_active()
        
        # Log if new user
        if created:
            logger.info(f"Created new user profile for Telegram ID: {telegram_id}, Name: {first_name}")
            
        return user_profile, created
    except Exception as e:
        logger.error(f"Error getting/creating user: {e}")
        return None, False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    
    # Get or create user profile
    user_profile, is_new_user = await get_or_create_user(
        user.id, 
        first_name=user.first_name
    )
    
    # If new user, show language selection and GDPR consent
    if is_new_user:
        return await welcome_new_user(update, context)
        
    # Create keyboard with WebApp button
    try:
        keyboard = [
            [InlineKeyboardButton(
                "🆘 Open Emergency App", 
                web_app=create_webapp_button(user.id)
            )],
            [InlineKeyboardButton("🌐 Change Language", callback_data="change_language")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_html(
            f"Hi {user.first_name}! I'm the Emergency Reporting Bot. "
            f"Use the button below to open the Emergency App and report incidents "
            f"or find nearby support agencies.\n\n"
            f"Current WebApp URL: {WEBAPP_URL}",
            reply_markup=reply_markup,
        )
    except Exception as e:
        logger.error(f"Error creating WebApp button: {e}")
        # Fallback without WebApp button
        await update.message.reply_html(
            f"Hi {user.first_name}! I'm the Emergency Reporting Bot. "
            f"I'm experiencing technical difficulties with the WebApp button. "
            f"Please try again later or contact support."
        )

async def welcome_new_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Welcome a new user with language selection."""
    user = update.effective_user
    
    # Create language selection keyboard
    keyboard = [
        [
            InlineKeyboardButton("English 🇬🇧", callback_data="lang_en"),
            InlineKeyboardButton("Amharic 🇪🇹", callback_data="lang_am")
        ],
        [
            InlineKeyboardButton("Afaan Oromo 🇪🇹", callback_data="lang_om")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(
        f"<b>Welcome {user.first_name}!</b>\n\n"
        f"Thank you for using the Emergency Reporting Bot. "
        f"First, please select your preferred language:",
        reply_markup=reply_markup,
    )

async def handle_language_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle language selection callback."""
    query = update.callback_query
    await query.answer()  # Answer the callback query
    
    user = query.from_user
    selected_lang = query.data.split('_')[1]  # Extract language code
    
    # Update user profile with selected language
    try:
        user_profile = UserProfile.objects.get(telegram_id=user.id)
        user_profile.language = selected_lang
        user_profile.save(update_fields=["language"])
        
        # Now show GDPR consent
        keyboard = [
            [InlineKeyboardButton("I Agree", callback_data="consent_agree")],
            [InlineKeyboardButton("Learn More", callback_data="consent_more")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        language_names = {"en": "English", "am": "Amharic", "om": "Afaan Oromo"}
        language_name = language_names.get(selected_lang, "Unknown")
        
        await query.edit_message_text(
            f"Language set to: {language_name}\n\n"
            f"<b>Data Privacy Consent</b>\n\n"
            f"To use this emergency reporting service, we need to collect some information "
            f"like your Telegram ID and incident reports you submit. This data is used only "
            f"to provide you with emergency services. You can request data deletion at any time.\n\n"
            f"Do you agree to these terms?",
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
    except Exception as e:
        logger.error(f"Error updating language: {e}")
        await query.edit_message_text(
            "Sorry, there was an error setting your language. Please try again with /start"
        )

async def handle_consent_response(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle user's response to consent request."""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    response = query.data.split('_')[1]
    
    if response == "agree":
        # Update user profile with consent
        try:
            user_profile = UserProfile.objects.get(telegram_id=user.id)
            user_profile.grant_consent()
            
            # Create keyboard with WebApp button
            keyboard = [
                [InlineKeyboardButton(
                    "🆘 Open Emergency App", 
                    web_app=create_webapp_button(user.id)
                )]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                f"Thank you for your consent! You're now ready to use the Emergency Reporting App.\n\n"
                f"Use the button below to open the app. You can report incidents, "
                f"find nearby support agencies, and manage your profile.",
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error updating consent: {e}")
            await query.edit_message_text(
                "Sorry, there was an error saving your consent. Please try again with /start"
            )
    elif response == "more":
        # Show more detailed privacy information
        keyboard = [
            [InlineKeyboardButton("I Agree", callback_data="consent_agree")],
            [InlineKeyboardButton("Decline", callback_data="consent_decline")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "<b>Privacy Policy Details</b>\n\n"
            "The Emergency Reporting System collects and processes the following data:\n"
            "• Your Telegram ID to identify you\n"
            "• Your language preference\n"
            "• Incident reports you submit (including location)\n"
            "• Voice notes (if you choose to record them)\n\n"
            "This data is used only to:\n"
            "• Provide emergency reporting services\n"
            "• Connect you with appropriate support agencies\n"
            "• Improve the service based on aggregated statistics\n\n"
            "You have the right to:\n"
            "• Access your data\n"
            "• Request deletion of your data\n"
            "• Withdraw consent at any time\n\n"
            "Do you agree to these terms?",
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
    elif response == "decline":
        await query.edit_message_text(
            "You have declined to provide consent. Unfortunately, you cannot use the "
            "Emergency Reporting System without consenting to our data processing.\n\n"
            "You can restart the process at any time with /start if you change your mind."
        )

async def change_language(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Allow existing users to change their language."""
    query = update.callback_query
    await query.answer()
    
    # Create language selection keyboard
    keyboard = [
        [
            InlineKeyboardButton("English 🇬🇧", callback_data="lang_en"),
            InlineKeyboardButton("Amharic 🇪🇹", callback_data="lang_am")
        ],
        [
            InlineKeyboardButton("Afaan Oromo 🇪🇹", callback_data="lang_om")
        ],
        [
            InlineKeyboardButton("← Back", callback_data="back_to_main")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "Please select your preferred language:",
        reply_markup=reply_markup
    )

async def back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Return to main menu."""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    
    # Create keyboard with WebApp button
    keyboard = [
        [InlineKeyboardButton(
            "🆘 Open Emergency App", 
            web_app=create_webapp_button(user.id)
        )],
        [InlineKeyboardButton("🌐 Change Language", callback_data="change_language")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"Emergency Reporting Bot\n\n"
        f"Use the button below to open the Emergency App and report incidents "
        f"or find nearby support agencies.\n\n"
        f"Current WebApp URL: {WEBAPP_URL}",
        reply_markup=reply_markup
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    help_text = (
        "This bot helps you report emergency incidents and find support agencies.\n\n"
        "Available commands:\n"
        "/start - Start the bot and open the emergency app\n"
        "/help - Show this help message\n"
        "/report - Report an emergency incident\n"
        "/agencies - Find nearby support agencies\n"
        "/language - Change your language\n"
        "/privacy - View privacy policy\n"
    )
    await update.message.reply_text(help_text)

async def language_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Allow users to change language via command."""
    # Create language selection keyboard
    keyboard = [
        [
            InlineKeyboardButton("English 🇬🇧", callback_data="lang_en"),
            InlineKeyboardButton("Amharic 🇪🇹", callback_data="lang_am")
        ],
        [
            InlineKeyboardButton("Afaan Oromo 🇪🇹", callback_data="lang_om")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Please select your preferred language:",
        reply_markup=reply_markup
    )

async def privacy_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show privacy policy information."""
    privacy_text = (
        "<b>Privacy Policy</b>\n\n"
        "The Emergency Reporting System collects and processes the following data:\n"
        "• Your Telegram ID to identify you\n"
        "• Your language preference\n"
        "• Incident reports you submit (including location)\n"
        "• Voice notes (if you choose to record them)\n\n"
        "This data is used only to:\n"
        "• Provide emergency reporting services\n"
        "• Connect you with appropriate support agencies\n"
        "• Improve the service based on aggregated statistics\n\n"
        "You have the right to:\n"
        "• Access your data\n"
        "• Request deletion of your data\n"
        "• Withdraw consent at any time\n\n"
        "To withdraw consent or request data deletion, use the /privacy_delete command."
    )
    
    await update.message.reply_html(privacy_text)

async def report_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Open the report incident page directly."""
    user = update.effective_user
    
    # Ensure user exists and has given consent
    user_profile, is_new_user = await get_or_create_user(
        user.id, 
        first_name=user.first_name
    )
    
    if is_new_user or not user_profile.data_consent:
        return await welcome_new_user(update, context)
    
    keyboard = [
        [InlineKeyboardButton(
            "📝 Report Incident", 
            web_app=create_webapp_button(user.id)
        )]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Please click the button below to report an incident:",
        reply_markup=reply_markup
    )

async def agencies_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Open the find agencies page directly."""
    user = update.effective_user
    
    # Ensure user exists and has given consent
    user_profile, is_new_user = await get_or_create_user(
        user.id, 
        first_name=user.first_name
    )
    
    if is_new_user or not user_profile.data_consent:
        return await welcome_new_user(update, context)
    
    keyboard = [
        [InlineKeyboardButton(
            "🔍 Find Support Agencies", 
            web_app=create_webapp_button(user.id)
        )]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Please click the button below to find support agencies near you:",
        reply_markup=reply_markup
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle regular messages."""
    await update.message.reply_text(
        "Please use the /start command to access the Emergency App or /help for more information."
    )

def create_application():
    """Create and configure the Application instance."""
    try:
        # Create application with increased timeout
        application = (
            Application.builder()
            .token(BOT_TOKEN)
            .connect_timeout(30.0)  # Increase connection timeout
            .read_timeout(30.0)     # Increase read timeout
            .write_timeout(30.0)    # Increase write timeout
            .build()
        )
        
        # Add handlers
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CommandHandler("help", help_command))
        application.add_handler(CommandHandler("report", report_command))
        application.add_handler(CommandHandler("agencies", agencies_command))
        application.add_handler(CommandHandler("language", language_command))
        application.add_handler(CommandHandler("privacy", privacy_command))
        
        # Add callback query handlers
        application.add_handler(CallbackQueryHandler(handle_language_selection, pattern=r"^lang_"))
        application.add_handler(CallbackQueryHandler(handle_consent_response, pattern=r"^consent_"))
        application.add_handler(CallbackQueryHandler(change_language, pattern=r"^change_language$"))
        application.add_handler(CallbackQueryHandler(back_to_main, pattern=r"^back_to_main$"))
        
        # Handle regular messages
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
        
        logger.info(f"Bot application created successfully with token: {BOT_TOKEN[:5]}...")
        logger.info(f"WebApp URL: {WEBAPP_URL}")
        
        return application
    except Exception as e:
        logger.error(f"Error creating bot application: {e}")
        raise 

def run_bot():
    """Run the bot in polling mode (used by management command)."""
    try:
        app = create_application()
        app.run_polling(allowed_updates=Update.ALL_TYPES)
    except Exception as e:
        logger.error(f"Error running bot in polling mode: {e}")
        raise 